from django.core.cache import cache
from surlydjango import SurlyDjango
from django.conf import settings
from django.test.signals import setting_changed
from django.dispatch import receiver
from django import get_version as django_version


def get_surly_django():
    surly = SurlyDjango(
        cache,
        toolbar_id=getattr(settings, 'SURLY_TOOLBAR_ID', None),
        use_shortener=getattr(settings, 'SURLY_ENABLE_SHORTENER', False),
        host=getattr(settings, 'SURLY_HOST', '') + ' django v' + django_version()
    )

    for domain in getattr(settings, 'SURLY_WHITE_LIST_DOMAINS', ()):
        surly.add_to_whitelist(domain)

    return surly

@receiver(setting_changed)
def surly_test_settings_change_listener(sender, **kwargs):
    global surly_django
    surly_django.update_white_list(getattr(settings, 'SURLY_WHITE_LIST_DOMAINS', ()))
    surly_django.toolbar_id = getattr(settings, 'SURLY_TOOLBAR_ID', None)
    if getattr(settings, 'SURLY_ENABLE_SHORTENER', False):
        surly_django._enable_shortener()


surly_django = get_surly_django()