from . import surly_django


class SurlyMiddleware(object):

    def process_response(self, request, response):
        """
        Process surly request
        :param request: HttpRequest
        :param response: HttpResponse
        :return:
        """
        if response.streaming:
            return response

        response.content = surly_django.process(response.content)

        return response