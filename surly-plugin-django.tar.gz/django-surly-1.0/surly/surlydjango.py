import hashlib

from surlylib.surly.surly import Surly


class SurlyDjango(Surly):
    PREFIX = '_surly_'
    ROOT_STATUS_KEY = PREFIX + 'root_status'

    def __init__(self, cache_client, toolbar_id=None, use_shortener=False, host=None):
        self.cache_client = cache_client
        super(SurlyDjango, self).__init__(toolbar_id, use_shortener, host)

    def _cache_short_ids(self, remote_short_ids):
        """
        Cache remote short ids using django cache abstraction
        :param remote_short_ids: dict
        """
        for url, shortened in remote_short_ids.items():
            self.cache_client.set(self.PREFIX + hashlib.md5(url.encode()).hexdigest(), shortened)

    def _get_cached_short_ids(self, urls):
        """
        Get short ids from django cache
        :param urls:
        :return:
        """
        url2shortened = {}
        for url in urls:
            url_shortened = self.cache_client.get(self.PREFIX + hashlib.md5(url.encode()).hexdigest())
            if url_shortened is None:
                continue
            url2shortened[url] = url_shortened

        return url2shortened

    def _get_cached_root_status(self):
        """
        Get root host status from cache
        :return: dict
        """
        return self.cache_client.get(self.ROOT_STATUS_KEY, {})

    def _cache_root_status(self, root_domain_alive_info):
        """
        Cache root status using django cache abstraction
        :param root_domain_alive_info:
        """
        self.cache_client.set(self.ROOT_STATUS_KEY, root_domain_alive_info)

    def update_white_list(self, whitelist=()):
        """
        Update (set) whitelist
        :param whitelist: tuple
        """
        self.whitelist = list(whitelist) + [self.SURLY_PANEL_HOST, self.SURLY_BACKUP_PANEL_HOST]