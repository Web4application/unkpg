from django import template
from django.utils.html import conditional_escape
from django.utils.safestring import mark_safe

from .. import surly_django as surly

register = template.Library()

@register.filter(needs_autoescape=True, name='surly')
def surly_filter(html, autoescape=None):
    if autoescape:
        esc = conditional_escape
    else:
        esc = lambda x: x
    return mark_safe(surly.process(esc(html)))

@register.tag(name="surly")
def surly_tag(parser, token):
    nodelist = parser.parse(('endsurly',))
    parser.delete_first_token()
    return SurlyNode(nodelist)


class SurlyNode(template.Node):
    def __init__(self, nodelist):
        self.nodelist = nodelist

    def render(self, context):
        return surly.process(self.nodelist.render(context))