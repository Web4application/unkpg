from __future__ import unicode_literals

from django.test import TestCase
from django.test.utils import override_settings
from django.template import Context, Template
from django.http import HttpRequest
from django.http import HttpResponse
from middleware import SurlyMiddleware

TEST_TOOLBAR_ID = 'AA001753'


@override_settings(
    SURLY_ENABLE_SHORTENER=True,
    SURLY_TOOLBAR_ID=TEST_TOOLBAR_ID,
    SURLY_WHITE_LIST_DOMAINS=()
)
class SurlyTagTest(TestCase):

    def _render_template(self, template, context):
        return Template("{% load surly %}" + template).render(context)

    def test_filter(self):
        """
        Test surly template filter
        """
        self.assertEqual(
            self._render_template(
                "{{ '<a href=\"http://google.com\">Google.com</a>'|surly }}",
                Context()
            ),
            "<a href=\"http://sur.ly/o/s/AA001753\">Google.com</a>"
        )

    @override_settings(SURLY_WHITE_LIST_DOMAINS=('google.com',))
    def test_filter_with_white_list(self):
        self.assertEqual(
            self._render_template(
                "{{ '<a href=\"http://google.com\">Google.com</a>'|surly }}",
                Context()
            ),
            "<a href=\"http://google.com\">Google.com</a>"
        )

    def test_tag(self):
        """
        Test surly template tag
        """
        self.assertEqual(
            self._render_template(
                "{% surly %}"
                "<ul>"
                "<li><a href=\"http://apple.com\">Apple.com</a></li>"
                "<li><a href=\"http://example.com\">Example.com</a></li>"
                "<li><a href=\"http://site.com/archives/493\">Site.com</a></li>"
                "<li><a href=\"http://www.somesite.com/?p=6362\">link</a></li>"
                "</ul>"
                "{% endsurly %}"
                ,
                Context()
            ),
            "<ul>"
            "<li><a href=\"http://sur.ly/o/uPp/AA001753\">Apple.com</a></li>"
            "<li><a href=\"http://sur.ly/o/czL/AA001753\">Example.com</a></li>"
            "<li><a href=\"http://sur.ly/o/lSgB/AA001753\">Site.com</a></li>"
            "<li><a href=\"http://sur.ly/o/somesite.com/%3Fp%3D6362/AA001753\">link</a></li>"
            "</ul>"
        )

    @override_settings(SURLY_WHITE_LIST_DOMAINS=('apple.com', 'somesite.com'))
    def test_tag_with_white_list(self):
        self.assertEqual(
            self._render_template(
                "{% surly %}"
                "<ul>"
                "<li><a href=\"http://apple.com\">Apple.com</a></li>"
                "<li><a href=\"http://example.com\">Example.com</a></li>"
                "<li><a href=\"http://site.com/archives/493\">Site.com</a></li>"
                "<li><a href=\"http://www.somesite.com/?p=6362\">link</a></li>"
                "</ul>"
                "{% endsurly %}"
                ,
                Context()
            ),
            "<ul>"
            "<li><a href=\"http://apple.com\">Apple.com</a></li>"
            "<li><a href=\"http://sur.ly/o/czL/AA001753\">Example.com</a></li>"
            "<li><a href=\"http://sur.ly/o/lSgB/AA001753\">Site.com</a></li>"
            "<li><a href=\"http://www.somesite.com/?p=6362\">link</a></li>"
            "</ul>"
        )


@override_settings(
    SURLY_ENABLE_SHORTENER=True,
    SURLY_TOOLBAR_ID=TEST_TOOLBAR_ID,
    SURLY_WHITE_LIST_DOMAINS=()
)
class SurlyMiddlewareTest(TestCase):

    def test_middleware_response(self):
        surly_middleware = SurlyMiddleware()

        self.assertEqual(
            surly_middleware.process_response(
                HttpRequest(),
                HttpResponse(
                    "<!DOCTYPE html>"
                    "<html>"
                    "<head>"
                    "<title>Myapp index</title>"
                    "</head>"
                    "<body>"
                    "<ul>"
                    "<li><a href=\"http://apple.com\">Apple.com</a></li>"
                    "<li><a href=\"http://example.com\">Example.com</a></li>"
                    "<li><a href=\"http://site.com/archives/493\">Site.com</a></li>"
                    "<li><a href=\"http://www.somesite.com/?p=6362\">link</a></li>"
                    "</ul>"
                    "</body>"
                    "</html>"
                )
            ).content,
            HttpResponse(
                "<!DOCTYPE html>"
                "<html>"
                "<head>"
                "<title>Myapp index</title>"
                "</head>"
                "<body>"
                "<ul>"
                "<li><a href=\"http://sur.ly/o/uPp/AA001753\">Apple.com</a></li>"
                "<li><a href=\"http://sur.ly/o/czL/AA001753\">Example.com</a></li>"
                "<li><a href=\"http://sur.ly/o/lSgB/AA001753\">Site.com</a></li>"
                "<li><a href=\"http://sur.ly/o/somesite.com/%3Fp%3D6362/AA001753\">link</a></li>"
                "</ul>"
                "</body>"
                "</html>"
            ).content
        )

    @override_settings(SURLY_WHITE_LIST_DOMAINS=('apple.com', 'somesite.com'))
    def test_middleware_response_with_white_list_domain(self):
        surly_middleware = SurlyMiddleware()

        self.assertEqual(
            surly_middleware.process_response(
                HttpRequest(),
                HttpResponse(
                    "<!DOCTYPE html>"
                    "<html>"
                    "<head>"
                    "<title>Myapp index</title>"
                    "</head>"
                    "<body>"
                    "<ul>"
                    "<li><a href=\"http://apple.com\">Apple.com</a></li>"
                    "<li><a href=\"http://example.com\">Example.com</a></li>"
                    "<li><a href=\"http://site.com/archives/493\">Site.com</a></li>"
                    "<li><a href=\"http://www.somesite.com/?p=6362\">link</a></li>"
                    "</ul>"
                    "</body>"
                    "</html>"
                )
            ).content,
            HttpResponse(
                "<!DOCTYPE html>"
                "<html>"
                "<head>"
                "<title>Myapp index</title>"
                "</head>"
                "<body>"
                "<ul>"
                "<li><a href=\"http://apple.com\">Apple.com</a></li>"
                "<li><a href=\"http://sur.ly/o/czL/AA001753\">Example.com</a></li>"
                "<li><a href=\"http://sur.ly/o/lSgB/AA001753\">Site.com</a></li>"
                "<li><a href=\"http://www.somesite.com/?p=6362\">link</a></li>"
                "</ul>"
                "</body>"
                "</html>"
            ).content
        )