=====
Surly
=====

Surly is a reusable django application for the users to be able to use
sur.ly service within django site. Surly provides several useful django tools
to wrap web content in templates and with middleware.

Quick start
-----------

1. Add "surly" to your `INSTALLED_APPS` in `settings.py` like this::

      INSTALLED_APPS = (
          ...
          'surly',
      )

2. Configuration. In project `settings.py` you should:

    a) set up your surly toolbar ID::

            SURLY_TOOLBAR_ID = 'your-toolbar-id-from-sur.ly'

    b) set up surly remote shortener. It gives an opportunity to use sur.ly shortener
       for URLs to be processed remotely. In this case your URLs will be processed in the most short way,
       otherwise all your URLs will be processed regularly::

            SURLY_ENABLE_SHORTENER = True

    c) set up domain that you do NOT want to be processed at all::

            SURLY_WHITE_LIST_DOMAINS = ('google.com', 'mydomain.com')

    d) finally set up your host (domain)::

            SURLY_HOST = "mydomain.com"

3. You can use surly several ways.

      a) Surly filter template feature::

            {% load surly %}
            {{ '<a href="http://google.com">Google.com</a>'|surly }}

      b) Surly tag template feature::

            {% load surly %}
            {% surly %}
                <a href="http://google.com">Google.com</a>
            {% endsurly %}

      c) Surly middleware. Open project `settings.py` and add `surly.middleware.SurlyMiddleware` to `MIDDLEWARE_CLASSES`.
         WARNING! Be sure to use template features OR middleware, but not both. Otherwise your urls will be
         processed twice.

        i) set it in `settings`::
    
            MIDDLEWARE_CLASSES = (
                ...
                'surly.middleware.SurlyMiddleware'
            )
    
        ii) set it in a view method as decorator::
              
             from django.utils.decorators import decorator_from_middleware
             from django.views.generic import TemplateView
             from surly.middleware import SurlyMiddleware

             class MyAppView(TemplateView):
                template_name = "index.html"

                @decorator_from_middleware(SurlyMiddleware)
                def get(self, request, *args, **kwargs):
                    return super(self.__class__, self).get(request, *args, **kwargs)


4. Now reload the server and use sur.ly shortener!