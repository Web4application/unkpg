import memcache
from examples.memcache_surly import MemcacheSurly


if __name__ == '__main__':
    my_memcache_surly = MemcacheSurly(
        memcache.Client(["127.0.0.1:11211"], debug=0),
        host="myhost.example.com",
        use_shortener=True,
        toolbar_id="MyToolBarId"
    )

    my_memcache_surly.add_to_whitelist("myhost.example.com")
    my_memcache_surly.add_to_whitelist("google.com")
    my_memcache_surly.add_to_whitelist("wikipedia.org")

    #finally process an HTML
    your_html = """
    <!DOCTYPE html>
        <html>
        <head>
            <title>cool page</title>
        </head>
        <body>
            <p>
                <a href="http://www.google.com/mail">Google.com</a>
                <ul>
                    <li><a href="http://facebook.com">Facebook</a></li>
                    <li><a href="http://myhost.example.com">myhost.example.com</a></li>
                    <li><a href="http://apple.com">Apple</a></li>
                </ul>
            </p>
        </body>
        </html>
    """
    clearedHtml = my_memcache_surly.process(your_html)

    print(clearedHtml)