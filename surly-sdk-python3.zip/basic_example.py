from surly import Surly

if __name__ == '__main__':
    surly = Surly(host="myhost.example.com", toolbar_id="MytoolbarID")

    surly.add_to_whitelist("myhost.example.com")
    surly.add_to_whitelist("google.com")
    surly.add_to_whitelist("wikipedia.org")

    #finally process an HTML
    your_html = """
    <!DOCTYPE html>
        <html>
        <head>
            <title>cool page</title>
        </head>
        <body>
            <p>
                <a href="http://www.google.com/mail">Google.com</a>
                <ul>
                    <li><a href="http://facebook.com">Facebook</a></li>
                    <li><a href="http://myhost.example.com">myhost.example.com</a></li>
                    <li><a href="http://apple.com">Apple</a></li>
                </ul>
            </p>
        </body>
        </html>
    """
    clearedHtml = surly.process(your_html)

    print(clearedHtml)